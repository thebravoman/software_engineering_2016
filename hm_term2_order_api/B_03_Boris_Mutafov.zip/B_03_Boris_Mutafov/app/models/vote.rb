class Vote < ApplicationRecord
end
